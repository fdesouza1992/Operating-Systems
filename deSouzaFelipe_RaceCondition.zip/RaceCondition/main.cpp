///////////////////////////////////////////////////////////////////////////////////
// #include any files need
///////////////////////////////////////////////////////////////////////////////////
#include <iostream>
#include <thread>
#include <vector>
#include <mutex>
#include <condition_variable>

// Include file and line numbers for memory leak detection for visual studio in debug mode
#if defined _MSC_VER && defined _DEBUG
	#include <crtdbg.h>
	#define new new(_NORMAL_BLOCK, __FILE__, __LINE__)
	#define ENABLE_LEAK_DETECTION() _CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF)
#else
	#define ENABLE_LEAK_DETECTION()
#endif

struct ThreadStruct
{
	// ID of the thread
	int id;
	// Length of the shared string
	int sharedStringLength;
	// Number of strings a single thread will generate
	int numberOfStringsToGenerate;
	// Shared string that will be generate in each thread. This memory is shared among all threads.
	char *sharedString;
	
	///////////////////////////////////////////////////////////////////////////////////
	// Add any extra variables needed by the threads here
	///////////////////////////////////////////////////////////////////////////////////	
	//Pointer to a shared mutex object to ensure mutal exclusion when threads access shared resources.
	std::mutex *pSharedMutex;
	//Pointer to a condition variable used for thread synchronization
	std::condition_variable *pConditionVariable;
	//Integer representing the type of operation or mode the thread will execute
	int runType;
	//Pointer to an integer representing the ID of the currently active thread
	int *pCurrentThreadId;
};

///////////////////////////////////////////////////////////////////////////////////////////
// Prompts the user to press enter and waits for user input
///////////////////////////////////////////////////////////////////////////////////////////
void Pause()
{
	printf("Press enter to continue\n");
	char ch = getchar();			// Added char ch to the existing code to fix a warning
}

///////////////////////////////////////////////////////////////////////////////////
// Entry point for worker threads. 
//
// Arguments:
//   threadData - Pointer to per-thread data for this thread.
///////////////////////////////////////////////////////////////////////////////////
void ThreadEntryPoint(ThreadStruct *threadData)
{
	///////////////////////////////////////////////////////////////////////////////////
	//  Add code to this function to make it run according to the run type.
	//		 However do NOT duplicate the following code.
	///////////////////////////////////////////////////////////////////////////////////	
	// runType2 = Run so a thread does all of its iterations before allowing any other thread to do their iterations
	if (threadData->runType == 2)
	{
		// Lock the shared mutex to ensure exclusive access to the shared string
		threadData->pSharedMutex->lock();
	}

	// runType3 = Run so that threads always run in the order thread 0 to thread n
	if (threadData->runType == 3) {
		// Lock the mutex for thread synch
		std::unique_lock<std::mutex> lock(*threadData->pSharedMutex);
		// Wait until it's this thread's turn
		threadData->pConditionVariable->wait(lock, [threadData]() {
			return *threadData->pCurrentThreadId == threadData->id;
			});
	}
	
	for(int i = 0; i < threadData->numberOfStringsToGenerate; i++, std::this_thread::sleep_for(std::chrono::milliseconds(10)))
	{
		// runType1 = Run so each string for a thread is always the same letter
		if (threadData->runType == 1) {
			// Lock the shared mutex to ensure exclusive access to the shared string
			threadData->pSharedMutex->lock();
		}

		for(int j = 0; j < threadData->sharedStringLength; j++)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1));
			threadData->sharedString[j] = 'A' + threadData->id;
		}
		printf("Thread %d: %s\n", threadData->id, threadData->sharedString);
		
		if (threadData->runType == 1) {
			// Unlock the shared mutex to allow other threads to access the shared resources
			threadData->pSharedMutex->unlock();
		}
	}
	if (threadData->runType == 2)
	{
		// Unlock the shared mutex to allow other threads to access the shared resources
		threadData->pSharedMutex->unlock();
	}

	if (threadData->runType == 3) {
		//Pre-Increment the currentThreadId and notify all threads
		++(*threadData->pCurrentThreadId);
		threadData->pConditionVariable->notify_all();
	}
	///////////////////////////////////////////////////////////////////////////////////
}

int main(int argc, char** argv)
{
	ENABLE_LEAK_DETECTION();

	int threadCount = 0;
	int sharedStringLength = 0;
	int numberOfStringsToGenerate = 0;
	int runType = 0;
	char *sharedString = nullptr;
	ThreadStruct *perThreadData = nullptr;

	///////////////////////////////////////////////////////////////////////////////////
	//		  Handle the runType command line argument.
	//
	//		  The following code already handles the first 4 arguments by ignoring
	//		  the first argument (which is just the name of the program) and reading
	//		  in the next 3 (threadCount, sharedStringLength, and numberOfStringsToGenerate).
	//
	//		  You will need to add code to this section to read in the final command line
	//		  argument (the runType). Once this is done you'll need to adjust the following
	//		  if check to expect one more argument. 
	///////////////////////////////////////////////////////////////////////////////////	


	if (argc != 5)
	{
		fprintf(stderr, "Error: missing or incorrect command line arguments\n\n"); 
		fprintf(stderr, "Usage: RaceCondition threadCount sharedStringLength numberOfStringsToGenerate runType\n\n");
		fprintf(stderr, "Arguments:\n");
		fprintf(stderr, "    threadCount                  Number of threads to create.\n");
		fprintf(stderr, "    sharedStringLength           Length of string to generate.\n");
		fprintf(stderr, "    numberOfStringsToGenerate    Number of strings to generate per thread.\n");
		fprintf(stderr, "    runType                      The run type.\n\n");
		Pause();
		return 1;
	}

	threadCount = atoi(argv[1]);
	sharedStringLength = atoi(argv[2]);
	numberOfStringsToGenerate = atoi(argv[3]);
	runType = atoi(argv[4]);

	if(threadCount < 0 || sharedStringLength < 0 || numberOfStringsToGenerate < 0 || runType < 0)
	{
		fprintf(stderr, "Error: All arguments must be positive integer values.\n");
		Pause();
		return 1;
	}

	printf("%d thread(s), string sharedStringLength %d, %d iterations, %d runType\n",
		threadCount, sharedStringLength, numberOfStringsToGenerate, runType);
	
	sharedString = new char[sharedStringLength + 1];
	memset(sharedString, 0, sharedStringLength + 1);
	perThreadData = new ThreadStruct[threadCount];
	
	///////////////////////////////////////////////////////////////////////////////////
	//   You will need a container to store the thread class objects. It is up to you
	//   to decide how you want to store the threads.
	///////////////////////////////////////////////////////////////////////////////////	
	std::vector<std::thread> Threads;
	std::mutex sharedMutex;
	std::condition_variable conditionVariable;
	int currentThreadId = 0;
	
	// NOTE: Do NOT change this for loop header
	for (int i = threadCount - 1; i >= 0; i--)
	{
		perThreadData[i].id = i;
		perThreadData[i].sharedStringLength = sharedStringLength;
		perThreadData[i].numberOfStringsToGenerate = numberOfStringsToGenerate;
		perThreadData[i].sharedString = sharedString;

		///////////////////////////////////////////////////////////////////////////////////
		//	Setup any additional variables in perThreadData and start (create) the threads.
		//	MUST be done in this for loop.
		///////////////////////////////////////////////////////////////////////////////////
		perThreadData[i].pSharedMutex = &sharedMutex;
		perThreadData[i].pConditionVariable = &conditionVariable;
		perThreadData[i].pCurrentThreadId = &currentThreadId;
		perThreadData[i].runType = runType;
		// perThreadData[i].threadCount = &threadCount;

		Threads.push_back(std::thread(ThreadEntryPoint, &perThreadData[i]));
	}

	///////////////////////////////////////////////////////////////////////////////////
	//   Wait for all of the threads to finish. Since we are using
	//   Joinable threads we must Join each one. Joining a thread will cause
	//   the calling thread (main in this case) to block until the thread being
	//   joined has completed executing.
	///////////////////////////////////////////////////////////////////////////////////	
	for (std::thread& thread : Threads)
	{
		thread.join();
	}

	Pause();
	
	///////////////////////////////////////////////////////////////////////////////////
	// Clean up
	///////////////////////////////////////////////////////////////////////////////////
	delete[] perThreadData;
	delete[] sharedString;
	return 0;
}
